#include<stdio.h>
#include<stdlib.h>

/*void first(int n, int* i, int *j,int* counter, int** matrix){
	int count = *counter;	
	matrix[0][n/2]= count;
	*counter=count;
}
*/
void empty(int n, int** matrix){
	for (int i =0; i<n; i++){
		for(int j = 0; j <n; j++){
			matrix[i][j]=0;
		}
	}
}

void next(int n, int* counter, int* i, int* j, int ** matrix){
	int r = *i;
	int c = *j; 
	int count = *counter;	
	if (count == 1){
		matrix[0][n/2]= count;
		*i = 0;
		*j = n/2;
	}
	else if (r-1>=0 && c+1<n){
		if(matrix[r-1][c+1] == 0){
			matrix[r-1][c+1] = count;
			r--;
			c++;
		}
		else{
			if(r+1<n){
				matrix[r+1][c] = count;
				r++;
			}
			else{
				r=0;
				matrix[r][c] = count;
			}
		}
		*i = r;
		*j = c;
		
	}
	else if(r-1<0 && c+1>=n){
		
		if (matrix[n-1][0] == 0){
			r = n-1;
			c = 0;
			matrix[r][c]= count;
			*i = r;
			*j = c;
		}
		else{
			r++; 
			matrix[r][c]= count;
			*i = r;
			*j = c;
		}
	}
	else if(r-1<0 && c+1<n){
		r = n-1;
		c++;
		matrix[r][c]= count;
		*i = r;
		*j = c;
	}
	else if(r-1>=0 && c+1>=n){
		r--;
		c = 0;
		matrix[r][c]= count;
		*i = r;
		*j = c;
	}
	count++;
	*counter =count;
	
}


void print (int n, int** matrix){
	for (int i =0; i<n; i++){
		for(int j = 0; j <n; j++){
			printf("%d",matrix[i][j]);
			if (j!=n){
				printf("	");
			}
		}
		if (i!=n){
			printf("\n");
		}
	}
}

void freeMatrix(int n, int ** matrix){
	for(int i =0; i<n; i++){
		free(matrix[i]);
	}
	free(matrix);
}

int main(int argc, char * argv[argc+1]){
	int n = atoi(argv[1]); 
	int counter =1;
	int max = n*n;
	int i = 0;
	int j = 0;
	if (n%2==0){
		printf("error");
		return EXIT_SUCCESS;
	}
	//allocate space for matrix
	int **matrix = malloc(n*sizeof(int*));
	for(int i =0; i <n; i++){
		matrix[i] = malloc(n * sizeof(int));
	}
	
	empty(n, matrix);
	while (counter <= max){
		next(n, &counter, &i, &j, matrix);
	}
	
	print(n, matrix);
	freeMatrix(n, matrix);

	return EXIT_SUCCESS;
}
