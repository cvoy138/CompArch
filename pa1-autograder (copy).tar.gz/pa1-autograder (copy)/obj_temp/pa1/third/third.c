#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>

struct Node{
	int data;
	struct Node* next;
};

struct Node* enqueue(int a, struct Node*);
struct Node* push(int a, struct Node*);
struct Node* pop(struct Node*);
void printLL(struct Node* head);
struct Node * allocate(int a);
void freeNode (struct Node* head);

struct Node* allocate(int val){
	struct Node* temp = malloc(sizeof(struct Node));
	temp->data = val;
	temp->next = 0;
	return temp;
}

void printLL(struct Node* head){
	struct Node* ptr = head;
	while (ptr != 0){
		if (ptr->next == 0){
			printf("%d", ptr->data);
		}
		else{
		printf("%d ", ptr->data);
		}		
		ptr= ptr->next;
	}
}

void freeNode(struct Node* head){
	if (head == 0){
		return;
	}
	
	struct Node* temp = head->next;

	free(head);
	freeNode(temp);

}

struct Node* push(int val, struct Node* head){
  if (head == 0){
		struct Node* temp = allocate(val);
		return temp;
	}
  struct Node* ptr= head;
	struct Node* new = allocate(val);
	if (ptr!= 0){
		new->data = val;
		new->next = ptr;
		return new;

	}
	return head;
}


struct Node* enqueue(int val, struct Node* head){
  if (head == 0){
		struct Node* temp = allocate(val);
		return temp;
	}

  struct Node* ptr= head;
	struct Node* prev = 0;
	struct Node* new = allocate(val);
	while(ptr!= 0){
		prev= ptr;
		ptr = ptr->next;
	}
  new->data = val;
  new->next = 0;
  prev->next = new; 
  return head;

}

struct Node* pop(struct Node* head){
  if (head == 0){
  	return head;
  }
  struct Node* ptr= head;
  head=ptr->next;
  free(ptr);
  return head;

}

int fExists(const char * filename){
    FILE *fptr = fopen(filename, "r");
    if(fptr ==NULL){
        return 0;
    }
    fclose(fptr); 
    return 1;
}

int main(int argc, char* argv[argc+1]){
  struct Node* head =0;
	char command[11]; 
	int num;
	int count =0;
  
   if (fExists(argv[1]) == 0){
    printf("error");
    return EXIT_SUCCESS;
  }

	FILE *fp = fopen(argv[1], "r");
  int arg = fscanf(fp,"%s %d\n", command, &num);
	while ((arg) >=1){
		if (count == 0){
      if (arg >1){
			  if (strcmp(command,"ENQUEUE") == 0){
				  head = enqueue(num, head);
				  printLL(head);
			  }
			  if((strcmp(command,"PUSH"))==0){
			  	head = push(num, head);
				  printLL(head);
			  }	
		  }
      else {
        
          head = pop(head);
          if (head ==0){
					  printf("EMPTY");
				  printLL(head);
          
			  }
      }
    }
	  else{ 
      printf("\n");
			if (arg >1){
			  if (strcmp(command,"ENQUEUE") == 0){
				  head = enqueue(num, head);
				  printLL(head);
			  }
			  else if((strcmp(command,"PUSH"))==0){
			  	head = push(num, head);
				  printLL(head);
			  }	
		  }
      else{
				  head = pop(head);
				  printLL(head);
          if (head ==0){
					  printf("EMPTY");			
				  }
			  
      }
		}
		count++;
    arg = fscanf(fp,"%s %d\n", command, &num);
	}

	fclose(fp);
  freeNode(head);

  return EXIT_SUCCESS;
}
