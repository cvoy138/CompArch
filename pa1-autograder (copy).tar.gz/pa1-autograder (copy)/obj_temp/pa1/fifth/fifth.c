#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void freeMatrix(int n, int ** matrix){
	for(int i =0; i<n; i++){
		free(matrix[i]);
	}
	free(matrix);
}

void empty(int n, int** matrix){
	for (int i =0; i<n; i++){
		for(int j = 0; j <n; j++){
			matrix[i][j]=0;
		}
	}
}


void print (int n, int** matrix){
	for (int i =0; i<n; i++){
		for(int j = 0; j <n; j++){
			printf("%d",matrix[i][j]);
			if (j!=n){
				printf("	");
			}
		}
		if (i!=n){
			printf("\n");
		}
	}
}


int det(int dim,  int **m){		
	int d = 0; 
	int sign = 1;
	int **sub = malloc((dim-1)*sizeof(int*));
	for(int i =0; i <dim-1; i++){
		sub[i] = malloc((dim-1)* sizeof(int));
	}
	
	if (dim ==1){
		freeMatrix(dim-1, sub);
		return m[0][0];
	}
	else if (dim ==2){
		int d = (m[0][0])*(m[1][1])-(m[0][1])*(m[1][0]);
		freeMatrix(dim-1, sub);
		
		return d; 
	}
	else{
	
		for (int i =0; i< dim; i++){
			int x = 0;
			int y = 0;
			for (int j =0; j< dim; j++){
				int n = 0;
				while(n< dim){
					if(j!=0 && n!=i){
						sub[x][y] = m[j][n];
						y++;
			
						if(y>dim-2){//resets columns and goes down row
							x++;
							y=0;
						}
						
					}
					n++;
				}	
			}
			
			d += sign*(m[0][i])*det(dim-1, sub);
			
			sign=(-1)*sign;
			//freeMatrix(dim-1, sub);
		}
		
	}
	freeMatrix(dim-1, sub);
	return (d);
	
	
	
}


int main (int argc, char* argv[argc+1]){
	FILE *fp = fopen(argv[1], "r");
	int dim; 
  	fscanf(fp,"%d", &dim);
  	
  	int **matrix = malloc(dim*sizeof(int*));
	for(int i =0; i <dim; i++){
		matrix[i] = malloc(dim * sizeof(int));
	}
  		 	
  	int entry;
	for (int i =0; i<dim; i++){
		for(int j = 0; j <dim; j++){
			fscanf(fp,"%d\n", &entry);
			matrix[i][j]=entry;
		}	
	}
	
	
  	if(dim == 1){
  		printf("%d\n",matrix[0][0]);
  		freeMatrix(dim, matrix);
		//freeMatrix(dim, sub);
  		return EXIT_SUCCESS;
  	}
  	if(dim == 2){
  		int a =(matrix[0][0])*(matrix[1][1])-(matrix[0][1])*(matrix[1][0]);
  		
  		printf("%d\n",a);
  		freeMatrix(dim, matrix);
		//freeMatrix(dim, sub);
  		return EXIT_SUCCESS;
  		
  	}
  	
  	/*
	for (int i =0; i<dim; i++){
		for(int j = 0; j <dim; j++){
			printf("%d",matrix[i][j]);
			if (j!=dim){
				printf("	");
			}
		}
		if (i!=dim){
			printf("\n");
		}
	}
	*/
	int deteriminant= det(dim, matrix);
	printf("%d",deteriminant);
	
	fclose(fp);
	freeMatrix(dim, matrix);
	//freeMatrix(dim, sub);
	
	return EXIT_SUCCESS;
}
