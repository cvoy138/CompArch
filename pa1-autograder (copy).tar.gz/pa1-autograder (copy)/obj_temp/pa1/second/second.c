#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>
struct Node{
	int data;
	struct Node* next;
};

struct Node* insert(int, struct Node*);
struct Node* delete(int, struct Node*);
void printLL(struct Node* head);
struct Node * allocate(int);
void freeNode (struct Node* head);

struct Node* allocate(int val){
	struct Node* temp = malloc(sizeof(struct Node));
	temp->data = val;
	temp->next = 0;
	return temp;
}

void printLL(struct Node* head){
	struct Node* ptr = head;
	while (ptr != 0){
		if (ptr->next == 0){
			printf("%d", ptr->data);
		}
		else{
		printf("%d ", ptr->data);
		}		
		ptr= ptr->next;
	}
}

void freeNode(struct Node* head){
	if (head == 0){
		return;
	}
	
	struct Node* temp = head->next;
	/*while(head != 0){
		temp = head;
		head = head->next;
		free(temp);

	}	
	*/

	free(head);
	freeNode(temp);

}


struct Node* insert(int val, struct Node* head){
	if (head == 0){
		struct Node* temp = allocate(val);
		return temp;
	}

	struct Node* ptr= head;
	struct Node* prev = 0;
	struct Node* new = allocate(val);
	while(ptr!= 0){
		/*
		else*/ 
		if(ptr->data == val){
			free(new);
			return head;
			
		}
		/*struct Node* p= 0;
		if(ptr->data == val){
			return head;
		}*/
		if (ptr->next== 0){
			if (ptr->data < val){
				new->data = val;
				new->next = 0;
				ptr-> next = new;
				return head;
			}
			if (ptr->data > val){
				new->data = val;
				
				if (prev==0){
					new->next=ptr;
					return new;
				}
				prev->next = new;
				new->next = ptr;
				return head;
			}
			
		}	
		
		else if(ptr->data < val){
			
			
			if (ptr->next == 0)
			{
				new->data = val;
				new->next = 0;
				ptr->next = new;
				return head;
			}
			prev = ptr;
			ptr = ptr->next;	
			
		}
		else if(ptr->data > val){

			if (prev == 0){
				new->data = val;
				new->next = ptr;
				return new;
			
			}

			new->data = val;
			new->next = ptr;
			prev->next = new;
			return head;
		}
		/*if (ptr->next== 0){
		new->data = val;
		new->next = 0;
		ptr-> next = new;
		return head;
		}*/	
		
	} 
	
	return head;
}	


struct Node* delete(int val, struct Node* head){

	if(head==0){
		return head;
	}
	struct Node* ptr= head;
	struct Node* prev = 0;
	while(ptr!= 0){
		if (ptr->data == val){
			
			if (prev != 0){
				prev->next = ptr->next;
				ptr->next = 0;
				free(ptr);
				return head;				
				
			}
			struct Node* temp= ptr;
			temp= temp->next;
			free(ptr);
			return temp;

		}
		
		prev = ptr;
		ptr = ptr->next;

	}
	
	return head;



}

int fExists(const char * filename){
    FILE *fptr = fopen(filename, "r");
    if(fptr ==NULL){
        return 0;
    }
    fclose(fptr); 
    return 1;
}



int main(int argc, char *argv[argc+1]){
  
  if (fExists(argv[1]) == 0){
    printf("error");
    return EXIT_SUCCESS;
  }

	struct Node* head =0;
	char command[7]; 
	//const char* i= ; 
	int num;
	int count =0;
	FILE *fp = fopen(argv[1], "r");
  
	while (fscanf(fp,"%s %d\n", command, &num) == 2){
		//int a = strcmp(command,"INSERT");		
		//printf("hello");
		if (count == 0){
			if (strcmp(command,"INSERT") == 0){
				head = insert(num, head);
				//printLL(head);
				printLL(head);
			}
			else if(strcmp(command,"DELETE")==0){
				head = delete(num, head);
				printLL(head);
				if (head ==0){
					printf("EMPTY");			
				}
			}	
		}
		else{
			printf("\n");
			if (strcmp(command,"INSERT") == 0){
				head = insert(num, head);
				//printLL(head);
				printLL(head);
			}
			else if(strcmp(command,"DELETE")==0){
				head = delete(num, head);
				printLL(head);
				if (head ==0){
					printf("EMPTY");			
				}
			}
		}
		count++;

	}
	fclose(fp);
/*
	head =insert(6, head);
	head =insert(1, head);
	head =insert(3, head);
	head =insert(5, head);
	head =delete(1, head);
	head =delete(6, head);
	head =delete(10, head);
*/
	//printLL(head);
	freeNode(head);




	return EXIT_SUCCESS;

}
