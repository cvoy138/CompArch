#include<stdio.h>
#include<stdlib.h>
#include<assert.h>


int isPrime(int a){
	
	int prime = 0; 
	for (int i = 2; i < a; i++){
		if (a%i == 0)
		{
			prime = 0;
			break;
		}
		else {
			prime = 1;
		}
	}
	return prime;
}

int twin(int a){
	if (a < 3){
		return 0;
	}	

	int n1 = isPrime(a-2);
	int n2 = isPrime(a+2);

	if (n1==1 || n2==1){
		return 1;
	}
	return 0;		
}




int main(int argc, char * argv[argc+1]){
/*	fp= fopen(
 *	format into for loop that takes scanned document and 
 *	repeats it for all numbers in file*/
	int counter = 1;
	int n =0;
	FILE *fp = fopen(argv[1], "r");
	while(fscanf(fp, "%d", &n) == 1){
	
		int p = isPrime(n);
		int t = 0;
		if (p == 1)
		{
			t = twin(n);
		}

		if (counter == 1){
			if (t==0){
			printf("no");	
	
			}
			else{
				printf("yes");
			}
		}
		else{
			if (t==0){
				printf("\nno");	
	
			}
			else{
				printf("\nyes");
			}
		}
		counter++;
	}

	fclose(fp);
	return EXIT_SUCCESS;
}


